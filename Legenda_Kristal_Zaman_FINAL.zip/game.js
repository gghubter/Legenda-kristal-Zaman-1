
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
let heroHP = 100;
let monsterHP = 100;
let gold = 50;
let powerUp = null;
let itemUsed = false;

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = 'white';
  ctx.font = '20px Arial';
  ctx.fillText('Pahlawan HP: ' + heroHP, 50, 50);
  ctx.fillText('Monster HP: ' + monsterHP, 600, 50);
  ctx.fillText('Gold: ' + gold, 350, 50);
}

function attack() {
  let baseDamage = Math.floor(Math.random() * 16 + 10); // 10-25
  if (powerUp === 'damage') baseDamage += 10;
  let critical = Math.random() < 0.2 ? Math.floor(Math.random() * 6 + 2) : 0;
  let totalDamage = baseDamage + critical;
  monsterHP -= totalDamage;
  if (monsterHP < 0) monsterHP = 0;
  document.getElementById('log').innerText = `Pahlawan menyerang! Damage: ${baseDamage}${critical ? ' + Critical: ' + critical : ''}`;
  draw();
}

function useItem() {
  if (!itemUsed && gold >= 10) {
    heroHP += Math.floor(Math.random() * 51 + 50); // 50-100
    gold -= 10;
    itemUsed = true;
    document.getElementById('log').innerText = 'Gunakan ramuan! HP bertambah.';
    draw();
  }
}

function nextEnemy() {
  if (monsterHP <= 0) {
    gold += Math.floor(Math.random() * 16 + 5); // 5-20
    monsterHP = 100;
    itemUsed = false;
    document.getElementById('log').innerText = 'Musuh baru muncul!';
    draw();
  } else {
    document.getElementById('log').innerText = 'Kalahkan musuh dulu!';
  }
}

draw();
